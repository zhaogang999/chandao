<?php
$lang->resource->project->deleterelation   = 'deleterelation';
$lang->resource->project->maintainrelation = 'editrelation';
$lang->resource->project->relation         = 'viewrelation';
$lang->resource->project->gantt            = 'ganttchart';
