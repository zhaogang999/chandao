<?php
$lang->project->menu->task['alias'] .= ',gantt,maintainrelation,relation';
