<?php
$config->dev->group['relationoftasks'] = 'project';
