<?php
$lang->dev->tableList['relationoftasks'] = '任务关系';
