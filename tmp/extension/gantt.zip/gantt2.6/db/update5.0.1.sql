ALTER TABLE `zt_relationoftasks` ADD INDEX `relationoftasks` (`project`, `task`);
