ALTER TABLE `zt_relationOfTasks` DROP `company`;
