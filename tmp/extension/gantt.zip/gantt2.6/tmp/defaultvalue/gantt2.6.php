<?php
$paramDefaultValue['project']['deleterelation']['confirm'] = 'no';
$paramDefaultValue['myproject']['gantt']['type'] = 'type';
$paramDefaultValue['myproject']['maintainrelation']['projectID'] = 0;
$paramDefaultValue['myproject']['relation']['projectID'] = 0;
