DELETE FROM `zt_grouppriv` WHERE `group` = 1 AND `module` = 'bug' AND `method` = 'exportTemplet';
DELETE FROM `zt_grouppriv` WHERE `group` = 4 AND `module` = 'bug' AND `method` = 'exportTemplet';

DELETE FROM `zt_grouppriv` WHERE `group` = 1 AND `module` = 'bug' AND `method` = 'import';
DELETE FROM `zt_grouppriv` WHERE `group` = 4 AND `module` = 'bug' AND `method` = 'import';

DELETE FROM `zt_grouppriv` WHERE `group` = 1 AND `module` = 'bug' AND `method` = 'showImport';
DELETE FROM `zt_grouppriv` WHERE `group` = 4 AND `module` = 'bug' AND `method` = 'showImport';

DELETE FROM `zt_grouppriv` WHERE `group` = 1 AND `module` = 'task' AND `method` = 'exportTemplet';
DELETE FROM `zt_grouppriv` WHERE `group` = 4 AND `module` = 'task' AND `method` = 'exportTemplet';

DELETE FROM `zt_grouppriv` WHERE `group` = 1 AND `module` = 'task' AND `method` = 'import';
DELETE FROM `zt_grouppriv` WHERE `group` = 4 AND `module` = 'task' AND `method` = 'import';

DELETE FROM `zt_grouppriv` WHERE `group` = 1 AND `module` = 'task' AND `method` = 'showImport';
DELETE FROM `zt_grouppriv` WHERE `group` = 4 AND `module` = 'task' AND `method` = 'showImport';

DELETE FROM `zt_grouppriv` WHERE `group` = 1 AND `module` = 'story' AND `method` = 'exportTemplet';
DELETE FROM `zt_grouppriv` WHERE `group` = 4 AND `module` = 'story' AND `method` = 'exportTemplet';

DELETE FROM `zt_grouppriv` WHERE `group` = 1 AND `module` = 'story' AND `method` = 'import';
DELETE FROM `zt_grouppriv` WHERE `group` = 4 AND `module` = 'story' AND `method` = 'import';

DELETE FROM `zt_grouppriv` WHERE `group` = 1 AND `module` = 'story' AND `method` = 'showImport';
DELETE FROM `zt_grouppriv` WHERE `group` = 4 AND `module` = 'story' AND `method` = 'showImport';
