<?php
$lang->story->importCase    = '导入需求';
$lang->story->import        = '导入';
$lang->story->exportTemplet = '导出模板';
$lang->story->showImport    = '显示导入内容';

$lang->story->new = '新增';

$lang->story->num = '需求记录数：';
