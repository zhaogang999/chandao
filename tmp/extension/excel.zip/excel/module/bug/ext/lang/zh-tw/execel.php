<?php
$lang->bug->importCase    = 'Bug導入';
$lang->bug->import        = '導入';
$lang->bug->exportTemplet = '導出模板';
$lang->bug->showImport    = '顯示導入內容';

$lang->bug->new = '新增';

$lang->bug->num = 'Bug記錄數：';
