<?php
$lang->word              = new stdclass();
$lang->word->fileField   = 'File';
$lang->word->headNotice  = 'The file are automatically exported by the ZenTao';
$lang->word->visitZentao = 'Visit ZenTao';
$lang->word->more        = 'Click to more';

$lang->word->notice           = new stdclass();
$lang->word->notice->noexport = 'There is no export function of the module.';
